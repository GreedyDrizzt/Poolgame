#include "regulation.h"


Regulation::Regulation()
{
    isPlayersTurn = false;
    m_game = nullptr;
}
